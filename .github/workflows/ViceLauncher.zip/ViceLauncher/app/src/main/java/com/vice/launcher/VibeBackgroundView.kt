package com.vice.launcher

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Animated neon-sunset backdrop: sky, striped sun, skyline, moving grid, palms. */
class VibeBackgroundView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private val rnd = Random(7)
    private val stars = List(70) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat() * 0.5f, rnd.nextFloat() * 6.28f) }
    private val towers = List(40) { floatArrayOf(rnd.nextFloat() * 0.12f + 0.02f, rnd.nextFloat() * 0.16f + 0.04f) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = (System.nanoTime() - t0) / 1e9f
        val hz = h * 0.68f

        // sky
        p.shader = LinearGradient(0f, 0f, 0f, hz,
            intArrayOf(0xFF12062E.toInt(), 0xFF4A1170.toInt(), 0xFFFF2E93.toInt(), 0xFFFF9A3C.toInt()),
            floatArrayOf(0f, 0.45f, 0.8f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, hz, p)
        p.shader = null

        // stars
        p.color = Color.WHITE
        for (s in stars) {
            p.alpha = (110 + 100 * sin(t * 1.5f + s[2])).toInt().coerceIn(0, 255)
            c.drawCircle(s[0] * w, s[1] * hz, 1.6f, p)
        }
        p.alpha = 255

        // sun + glow
        val r = h * 0.26f
        val cx = w * 0.62f
        val cy = hz - r * 0.55f + sin(t * 0.4f) * 4f
        p.shader = RadialGradient(cx, cy, r * 1.8f, 0x66FF2E93, 0x00FF2E93, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.8f, p)
        p.shader = null
        val layer = c.saveLayer(0f, 0f, w, h, null)
        p.shader = LinearGradient(0f, cy - r, 0f, cy + r, 0xFFFFE259.toInt(), 0xFFFF2E93.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        var y = cy + r * 0.05f
        var bar = r * 0.04f
        while (y < cy + r) {
            c.drawRect(cx - r, y, cx + r, y + bar, p)
            y += bar + r * 0.09f
            bar += r * 0.012f
        }
        p.xfermode = null
        c.restoreToCount(layer)

        // skyline
        p.color = 0xFF1A0838.toInt()
        var x = -w * 0.02f
        var i = 0
        while (x < w) {
            val tw = towers[i % towers.size][0] * w * 0.6f
            c.drawRect(x, hz - towers[i % towers.size][1] * h, x + tw, hz + 2f, p)
            x += tw + 3f; i++
        }

        // ground + moving grid
        p.shader = LinearGradient(0f, hz, 0f, h, 0xFF1A0838.toInt(), 0xFF0B0420.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, hz, w, h, p)
        p.shader = null
        p.color = 0xFF00F0FF.toInt(); p.style = Paint.Style.STROKE; p.strokeWidth = 2f
        val n = 12
        val phase = (t * 0.25f) % 1f
        for (k in 0 until n) {
            val f = (k + phase) / n
            val ly = hz + (h - hz) * f * f
            p.alpha = (40 + 150 * f).toInt().coerceIn(0, 255)
            c.drawLine(0f, ly, w, ly, p)
        }
        for (k in -12..12) {
            p.alpha = 90
            c.drawLine(cx, hz, cx + k * w * 0.12f, h, p)
        }
        p.alpha = 255; p.style = Paint.Style.FILL

        // palms
        palm(c, w * 0.05f, h + 10f, h * 0.78f, w * 0.05f)
        palm(c, w * 0.13f, h + 10f, h * 0.5f, -w * 0.02f)
        palm(c, w * 0.96f, h + 10f, h * 0.72f, -w * 0.05f)

        // readability fade behind the app row
        p.shader = LinearGradient(0f, h * 0.62f, 0f, h, 0x0012062E, 0xDD12062E.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, h * 0.62f, w, h, p)
        p.shader = null

        postInvalidateOnAnimation()
    }

    private fun palm(c: Canvas, x: Float, baseY: Float, ph: Float, lean: Float) {
        p.color = 0xFF0B0420.toInt(); p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        val tx = x + lean; val ty = baseY - ph
        val trunk = Path().apply { moveTo(x, baseY); quadTo(x + lean * 0.1f, baseY - ph * 0.5f, tx, ty) }
        p.strokeWidth = ph * 0.03f; c.drawPath(trunk, p)
        p.strokeWidth = ph * 0.018f
        val len = ph * 0.32f
        for (a in listOf(-170f, -140f, -110f, -70f, -40f, -10f)) {
            val rad = Math.toRadians(a.toDouble())
            val ex = tx + (cos(rad) * len).toFloat()
            val ey = ty + (sin(rad) * len).toFloat() + len * 0.55f
            val mx = tx + (cos(rad) * len * 0.5).toFloat()
            val my = ty + (sin(rad) * len).toFloat() * 0.9f - len * 0.15f
            c.drawPath(Path().apply { moveTo(tx, ty); quadTo(mx, my, ex, ey) }, p)
        }
        p.style = Paint.Style.FILL
    }
}
