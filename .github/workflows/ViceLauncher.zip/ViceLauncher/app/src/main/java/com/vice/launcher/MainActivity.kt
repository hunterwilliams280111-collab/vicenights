package com.vice.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*

class MainActivity : Activity() {
    private val PINK = 0x66FF2E93
    private val CYAN = 0xFF00F0FF.toInt()
    private var dens = 1f
    private fun dp(v: Int) = (v * dens).toInt()

    data class App(val label: String, val art: Drawable, val isBanner: Boolean, val cn: ComponentName)

    // ---- Edit this to rename the header ----
    private val HEADER = "VICE NIGHTS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dens = resources.displayMetrics.density
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this)
        root.addView(VibeBackgroundView(this))

        val title = TextView(this).apply {
            text = HEADER
            setTextColor(CYAN)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            letterSpacing = 0.35f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(16f, 0f, 0f, CYAN)
        }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 64f)
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
            setShadowLayer(24f, 0f, 0f, 0xFFFF2E93.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title); addView(clock)
        }
        root.addView(header, FrameLayout.LayoutParams(-2, -2).apply { leftMargin = dp(56); topMargin = dp(36) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(56), dp(28), dp(56), dp(28))
            clipChildren = false; clipToPadding = false
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false; clipToPadding = false
            addView(row)
        }
        root.addView(scroller, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = dp(36) })

        row.addView(makeTile("Settings", getDrawable(android.R.drawable.ic_menu_preferences)!!, false) {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        for (a in loadApps()) {
            row.addView(makeTile(a.label, a.art, a.isBanner) {
                startActivity(Intent(Intent.ACTION_MAIN).setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }
        setContentView(root)
        row.post { row.getChildAt(0)?.requestFocus() }
    }

    private fun loadApps(): List<App> {
        val pm = packageManager
        val seen = HashSet<String>()
        val out = ArrayList<App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val ai = ri.activityInfo
                if (ai.packageName == packageName || !seen.add(ai.packageName)) continue
                val banner = ai.loadBanner(pm)
                out.add(App(ri.loadLabel(pm).toString(), banner ?: ri.loadIcon(pm), banner != null,
                    ComponentName(ai.packageName, ai.name)))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    private fun makeTile(label: String, art: Drawable, wide: Boolean, onClick: () -> Unit): View {
        val card = FrameLayout(this)
        val base = GradientDrawable().apply { setColor(0xEE1A0838.toInt()); cornerRadius = dp(14).toFloat() }
        val ring = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = dp(14).toFloat(); setStroke(dp(2), PINK)
        }
        card.background = base
        card.foreground = ring
        card.outlineProvider = ViewOutlineProvider.BACKGROUND
        card.clipToOutline = true
        card.isFocusable = true
        card.isClickable = true

        val img = ImageView(this).apply {
            setImageDrawable(art)
            scaleType = if (wide) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            if (!wide) setPadding(dp(40), dp(14), dp(40), dp(34))
        }
        card.addView(img, -1, -1)

        val tv = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setBackgroundColor(0xAA12062E.toInt())
        }
        card.addView(tv, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        card.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.14f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            v.translationZ = if (focused) dp(12).toFloat() else 0f
            ring.setStroke(dp(if (focused) 4 else 2), if (focused) CYAN else PINK)
        }
        card.setOnClickListener { try { onClick() } catch (_: Exception) {} }
        card.layoutParams = LinearLayout.LayoutParams(dp(224), dp(126)).apply { rightMargin = dp(22) }
        return card
    }

    override fun onBackPressed() { /* a launcher shouldn't exit */ }
}
