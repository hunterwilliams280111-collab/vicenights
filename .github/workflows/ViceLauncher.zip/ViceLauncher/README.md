# Vice Nights – a neon-sunset Fire TV launcher + screensaver

Fan-made, original artwork drawn in code (no Rockstar/Take-Two assets).

## Easiest way: GitHub release (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder, including the hidden `.github` folder.
   If the web uploader skips `.github`, use Add file > Create new file, type `.github/workflows/release.yml`, and paste that file's contents.
2. Go to the repo's Actions tab > "Build and release APK" > Run workflow.
3. After about 3 minutes, the Releases page has `ViceNights.apk`.

## Install on Fire TV (Android-based Fire OS only)
1. Install the free "Downloader" app from the Amazon Appstore.
2. Settings > My Fire TV > Developer Options > Install unknown apps > turn on Downloader.
3. In Downloader, enter: https://github.com/YOUR_USER/YOUR_REPO/releases/latest/download/ViceNights.apk
4. Install, then open "Vice Nights" from Your Apps & Channels.

## Optional: build locally / install over ADB
Open in Android Studio, Build APK, then ./scripts/install.sh <tv-ip>

## Using it
- Open "Vice Nights" from Your Apps & Channels. It lists every installed app as a neon tile.
- Screensaver: Settings > Display & Sounds > Screensaver (if the script's setting didn't stick).
- Home button: Fire OS normally forces Amazon's home. Community launcher-switcher tools exist, results vary by Fire OS version.

## Customise
- Header text: HEADER in MainActivity.kt
- Colours/sun/palms/grid: VibeBackgroundView.kt
