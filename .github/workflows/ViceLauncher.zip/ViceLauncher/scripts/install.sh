#!/usr/bin/env bash
# Usage: ./scripts/install.sh <firetv-ip> [apk]
# Fire TV: Settings > My Fire TV > Developer Options > ADB debugging = ON
set -e
IP="$1"; APK="${2:-app/build/outputs/apk/debug/app-debug.apk}"
[ -z "$IP" ] && { echo "usage: $0 <firetv-ip> [apk]"; exit 1; }
adb connect "$IP:5555"
D="adb -s $IP:5555"
$D install -r "$APK"
# Best effort: set the neon screensaver (some Fire OS builds ignore third-party dreams)
$D shell settings put secure screensaver_components com.vice.launcher/com.vice.launcher.VibeDream || true
$D shell settings put secure screensaver_enabled 1 || true
$D shell am start -n com.vice.launcher/.MainActivity
